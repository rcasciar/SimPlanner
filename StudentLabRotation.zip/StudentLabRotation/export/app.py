"""
Lab Scheduling Application.

A Streamlit app to schedule 75 students across 16 laboratories with varying capacities 
and constraints over a 14-day period.
"""
import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import plotly.express as px
import plotly.graph_objects as go

from models import ScheduleData
from scheduler import LabScheduler

# Set page config
st.set_page_config(
    page_title="Sistema di Programmazione Laboratori",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Title and description
st.title("Sistema di Programmazione Laboratori")
st.markdown("""
    Questa applicazione consente di generare una programmazione ottimizzata per la rotazione 
    di studenti tra diversi laboratori, gestendo vincoli di capacità, durata e disponibilità delle aule.
    Inoltre, gestisce l'inventario dei dispositivi utilizzati nei laboratori.
""")

# Initialize session state variables
if 'start_date' not in st.session_state:
    st.session_state.start_date = datetime.now().date()
if 'end_date' not in st.session_state:
    st.session_state.end_date = (datetime.now() + timedelta(days=14)).date()
if 'schedule_data' not in st.session_state:
    st.session_state.schedule_data = ScheduleData()
if 'schedule_created' not in st.session_state:
    st.session_state.schedule_created = False
if 'scheduler' not in st.session_state:
    st.session_state.scheduler = LabScheduler(st.session_state.schedule_data)
if 'student_list' not in st.session_state:
    st.session_state.student_list = ""

# Input area for student list and date range
st.subheader("Dati di Input")
col1, col2 = st.columns(2)

with col1:
    st.subheader("Elenco Studenti")
    
    # Tabs for different input methods
    tab1, tab2 = st.tabs(["Caricamento File Excel", "Inserimento Manuale"])
    
    with tab1:
        st.write("Carica un file Excel con elenco studenti")
        uploaded_file = st.file_uploader("Scegli un file Excel", type=["xlsx", "xls"])
        
        if uploaded_file is not None:
            try:
                # Read the Excel file
                df = pd.read_excel(uploaded_file)
                
                # Check if the required columns exist
                if "cognome" in map(str.lower, df.columns) and "nome" in map(str.lower, df.columns):
                    # Get column names (case insensitive)
                    cognome_col = next(col for col in df.columns if col.lower() == "cognome")
                    nome_col = next(col for col in df.columns if col.lower() == "nome")
                    
                    # Create a list of "Cognome Nome" for each student
                    excel_students = [f"{row[cognome_col]} {row[nome_col]}" for _, row in df.iterrows()]
                    student_list = "\n".join(excel_students)
                    
                    st.success(f"File caricato con successo! {len(excel_students)} studenti trovati.")
                    st.session_state.student_list = student_list
                else:
                    st.error("Il file Excel deve contenere le colonne 'Cognome' e 'Nome'.")
                    if 'student_list' not in st.session_state:
                        st.session_state.student_list = ""
            except Exception as e:
                st.error(f"Errore nel caricamento del file: {e}")
                if 'student_list' not in st.session_state:
                    st.session_state.student_list = ""
    
    with tab2:
        student_list = st.text_area(
            "Inserisci l'elenco degli studenti (uno per riga)",
            value=st.session_state.student_list,  # Use existing data if available
            height=200,
            help="Inserisci ogni nome studente su una riga separata nel formato 'Cognome Nome'"
        )
        st.session_state.student_list = student_list
    
    # Calculate number of students
    if st.session_state.student_list.strip():
        students = [s.strip() for s in st.session_state.student_list.split('\n') if s.strip()]
        num_students = len(students)
        st.info(f"Numero di studenti: {num_students}")
    else:
        st.error("Inserisci almeno uno studente per generare la programmazione.")
        num_students = 0

with col2:
    st.subheader("Periodo Laboratori")
    start_date = st.date_input("Data di inizio", value=st.session_state.start_date)
    end_date = st.date_input("Data di fine", value=st.session_state.end_date)
    
    # Validate dates
    if start_date >= end_date:
        st.error("La data di fine deve essere successiva alla data di inizio")
    else:
        days_between = (end_date - start_date).days + 1
        weekdays = sum(1 for i in range(days_between) if (start_date + timedelta(days=i)).weekday() < 5)
        st.info(f"Periodo selezionato: {weekdays} giorni feriali (lun-ven)")
        
    st.session_state.start_date = start_date
    st.session_state.end_date = end_date

# Button to generate schedule
if st.button("Genera Programmazione"):
    with st.spinner("Generazione programmazione in corso... Potrebbe richiedere un momento."):
        # Get actual number of students from session state
        if st.session_state.student_list.strip():
            students = [s.strip() for s in st.session_state.student_list.split('\n') if s.strip()]
            num_students = len(students)
            
            # Reset the schedule data
            st.session_state.schedule_data = ScheduleData(total_students=num_students)
            st.session_state.scheduler = LabScheduler(st.session_state.schedule_data)
            
            # Generate the schedule
            success = st.session_state.scheduler.create_schedule()
            
            if success:
                st.session_state.schedule_created = True
                st.success("Programmazione generata con successo!")
            else:
                st.error("Impossibile generare una programmazione completa. Prova a modificare i parametri.")
        else:
            st.error("Devi inserire almeno uno studente per generare la programmazione.")

# Display laboratory information in sidebar
st.sidebar.title("Informazioni")

# Laboratory details
st.sidebar.subheader("Dettagli Laboratori")
with st.sidebar.expander("Mostra Dettagli Laboratori"):
    # Create a dataframe for labs
    lab_data = []
    for lab in st.session_state.schedule_data.laboratories:
        lab_data.append({
            "Nome": lab.name,
            "Durata (min)": lab.duration_minutes,
            "Capacità": f"{lab.min_students}-{lab.max_students}",
            "Capacità Ridotta": "Sì" if lab.is_small_capacity else "No",
        })
    st.dataframe(pd.DataFrame(lab_data), use_container_width=True)

# Room details
with st.sidebar.expander("Mostra Dettagli Aule"):
    # Create a dataframe for rooms
    room_data = []
    for room in st.session_state.schedule_data.rooms:
        room_data.append({
            "Nome": room.name,
            "Capacità": room.capacity,
        })
    st.dataframe(pd.DataFrame(room_data), use_container_width=True)

# Main content area - Tabs
tab1, tab2, tab3, tab4 = st.tabs([
    "Programmazione", 
    "Dispositivi Laboratorio", 
    "Inventario",
    "Gestione Completamento"
])

# Tab 1: Programmazione
with tab1:
    if st.session_state.schedule_created:
        # Get the data frame for the schedule
        df = st.session_state.schedule_data.get_data_frame()
        
        # Display the main schedule table
        st.subheader("Programmazione Generata")
        
        if not df.empty:
            # Prepare a clean table with the requested columns
            schedule_table = []
            
            # Generate student names if they were provided
            if st.session_state.student_list.strip():
                students = [s.strip() for s in st.session_state.student_list.split('\n') if s.strip()]
            else:
                students = [f"Studente {i+1}" for i in range(st.session_state.schedule_data.total_students)]
            
            # Weekday names in Italian
            giorni = ["Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì"]
            
            for slab in st.session_state.schedule_data.scheduled_labs:
                # Calculate actual day of the week (0-4 for Mon-Fri)
                week = slab.time_slot.day // 5
                weekday_idx = slab.time_slot.day % 5
                weekday = giorni[weekday_idx]
                
                # Format the date as "Settimana X, Giorno"
                date_str = f"Settimana {week+1}, {weekday}"
                
                # Get student names for this lab session
                student_names = []
                for student_id in slab.students:
                    if student_id <= len(students):
                        student_names.append(students[student_id-1])
                    else:
                        student_names.append(f"Studente {student_id}")
                
                # Format student list
                student_str = ", ".join(student_names)
                if len(student_str) > 50:  # Truncate if too long
                    student_str = student_str[:47] + "..."
                
                # Add this lab to the table
                schedule_table.append({
                    "Laboratorio": slab.lab.name,
                    "Aula": slab.room.name,
                    "Data": date_str,
                    "Orario": f"{slab.time_slot.start_time.strftime('%H:%M')} - {slab.time_slot.end_time.strftime('%H:%M')}",
                    "Gruppo Studenti": student_str,
                    "Numero Studenti": len(slab.students)
                })
            
            # Create DataFrame and sort by date and time
            schedule_df = pd.DataFrame(schedule_table)
            schedule_df["Settimana"] = schedule_df["Data"].str.extract(r'Settimana (\d+)').astype(int)
            schedule_df["Giorno"] = schedule_df["Data"].str.extract(r', (\w+)')
            day_order = {day: i for i, day in enumerate(giorni)}
            schedule_df["Ordine Giorno"] = schedule_df["Giorno"].map(day_order)
            schedule_df = schedule_df.sort_values(["Settimana", "Ordine Giorno", "Orario"])
            schedule_df = schedule_df.drop(["Settimana", "Ordine Giorno"], axis=1)
            
            # Display the final table
            st.dataframe(schedule_df, use_container_width=True)
            
            # Add download button for Excel export
            st.download_button(
                label="Scarica come Excel",
                data=schedule_df.to_csv(index=False).encode('utf-8'),
                file_name="programmazione_laboratori.csv",
                mime="text/csv",
            )
            
            # Summary statistics
            st.subheader("Statistiche")
            col1, col2 = st.columns(2)
            
            with col1:
                total_sessions = len(schedule_df)
                labs_covered = len(schedule_df["Laboratorio"].unique())
                
                st.metric("Totale Sessioni Programmate", total_sessions)
                st.metric("Laboratori Coperti", f"{labs_covered}/16")
            
            with col2:
                # Check if all students have been assigned all labs
                all_assigned = True
                for lab in st.session_state.schedule_data.laboratories:
                    lab_sessions = st.session_state.schedule_data.get_lab_schedule(lab.id)
                    students_assigned = set()
                    for session in lab_sessions:
                        students_assigned.update(session.students)
                    
                    if len(students_assigned) < st.session_state.schedule_data.total_students:
                        all_assigned = False
                        break
                
                if all_assigned:
                    st.success("Tutti gli studenti sono stati assegnati a tutti i laboratori!")
                else:
                    st.warning("Non tutti gli studenti sono stati assegnati a tutti i laboratori.")
            
            # Student lookup
            st.subheader("Cerca Programmazione Studente")
            if st.session_state.student_list.strip():
                # Use dropdown to select student from the provided names
                selected_student = st.selectbox(
                    "Seleziona uno studente",
                    options=range(len(students)),
                    format_func=lambda i: students[i]
                )
                student_id = selected_student + 1  # Adjust for 1-based index
            else:
                # Use number input if no names were provided
                student_id = st.number_input(
                    "Inserisci ID Studente", 
                    min_value=1, 
                    max_value=st.session_state.schedule_data.total_students,
                    value=1
                )
            
            if st.button("Cerca"):
                # Get the schedule for this student
                student_labs = []
                for slab in st.session_state.schedule_data.scheduled_labs:
                    if student_id in slab.students:
                        # Calculate actual day of the week (0-4 for Mon-Fri)
                        week = slab.time_slot.day // 5
                        weekday_idx = slab.time_slot.day % 5
                        weekday = giorni[weekday_idx]
                        
                        # Format the date as "Settimana X, Giorno"
                        date_str = f"Settimana {week+1}, {weekday}"
                        
                        student_labs.append({
                            "Laboratorio": slab.lab.name,
                            "Aula": slab.room.name,
                            "Data": date_str,
                            "Orario": f"{slab.time_slot.start_time.strftime('%H:%M')} - {slab.time_slot.end_time.strftime('%H:%M')}",
                        })
                
                if student_labs:
                    # Sort by date
                    student_df = pd.DataFrame(student_labs)
                    student_df["Settimana"] = student_df["Data"].str.extract(r'Settimana (\d+)').astype(int)
                    student_df["Giorno"] = student_df["Data"].str.extract(r', (\w+)')
                    day_order = {day: i for i, day in enumerate(giorni)}
                    student_df["Ordine Giorno"] = student_df["Giorno"].map(day_order)
                    student_df = student_df.sort_values(["Settimana", "Ordine Giorno"])
                    student_df = student_df.drop(["Settimana", "Ordine Giorno"], axis=1)
                    
                    st.dataframe(student_df, use_container_width=True)
                    
                    # Add download button for this student's schedule
                    student_name = students[student_id-1] if student_id <= len(students) else f"Studente_{student_id}"
                    st.download_button(
                        label=f"Scarica programmazione di {student_name}",
                        data=student_df.to_csv(index=False).encode('utf-8'),
                        file_name=f"programmazione_{student_name}.csv",
                        mime="text/csv",
                    )
                else:
                    student_name = students[student_id-1] if student_id <= len(students) else f"Studente {student_id}"
                    st.info(f"Nessun laboratorio programmato per {student_name}.")
        else:
            st.info("Nessun laboratorio programmato da visualizzare.")
    else:
        # Display instructions if no schedule has been created yet
        st.info("Inserisci i dati richiesti e premi 'Genera Programmazione' per creare una nuova programmazione.")
        
        # Show a placeholder
        st.subheader("Anteprima Programmazione")
        st.write("La programmazione apparirà qui dopo la generazione.")

# Tab 2: Dispositivi Laboratorio
with tab2:
    st.subheader("Dispositivi Laboratorio")
    st.write("In questa sezione puoi specificare i dispositivi necessari per ogni laboratorio.")
    
    # Create columns for different input methods
    device_col1, device_col2 = st.columns(2)
    
    with device_col1:
        # Add a new device
        st.subheader("Aggiungi Dispositivo")
        new_device_name = st.text_input("Nome Dispositivo")
        new_device_desc = st.text_area("Descrizione", height=100)
        
        if st.button("Aggiungi Dispositivo") and new_device_name:
            # Check if device already exists
            if new_device_name in st.session_state.schedule_data.device_manager.devices:
                st.error(f"Il dispositivo '{new_device_name}' esiste già.")
            else:
                # Add the device
                st.session_state.schedule_data.device_manager.add_device(
                    name=new_device_name, 
                    description=new_device_desc
                )
                st.success(f"Dispositivo '{new_device_name}' aggiunto!")
        
        # Upload Excel file for device types
        st.subheader("Carica Dispositivi da Excel")
        device_upload = st.file_uploader("Carica file Excel con dispositivi", type=["xlsx", "xls"], key="device_upload")
        
        if device_upload is not None:
            try:
                # Read the Excel file
                df_devices = pd.read_excel(device_upload)
                
                # Check if required columns exist
                if "nome" in map(str.lower, df_devices.columns):
                    # Get column names (case insensitive)
                    nome_col = next(col for col in df_devices.columns if col.lower() == "nome")
                    
                    # Optional description column
                    desc_col = None
                    if "descrizione" in map(str.lower, df_devices.columns):
                        desc_col = next(col for col in df_devices.columns if col.lower() == "descrizione")
                    
                    # Add each device
                    devices_added = 0
                    for _, row in df_devices.iterrows():
                        device_name = row[nome_col]
                        if not pd.isna(device_name) and device_name:
                            device_desc = row.get(desc_col, "") if desc_col else ""
                            if device_name not in st.session_state.schedule_data.device_manager.devices:
                                st.session_state.schedule_data.device_manager.add_device(
                                    name=device_name,
                                    description=str(device_desc) if not pd.isna(device_desc) else ""
                                )
                                devices_added += 1
                    
                    st.success(f"{devices_added} dispositivi aggiunti dal file Excel.")
                else:
                    st.error("Il file Excel deve contenere una colonna 'Nome'.")
            except Exception as e:
                st.error(f"Errore nel caricamento del file: {e}")
    
    with device_col2:
        # Associate devices with laboratories
        st.subheader("Assegna Dispositivi ai Laboratori")
        
        # Get available labs and devices
        available_labs = [(lab.id, lab.name) for lab in st.session_state.schedule_data.laboratories]
        available_devices = list(st.session_state.schedule_data.device_manager.devices.keys())
        
        if available_labs and available_devices:
            # Select lab
            selected_lab_id = st.selectbox(
                "Seleziona Laboratorio",
                options=[lab[0] for lab in available_labs],
                format_func=lambda lab_id: next(lab[1] for lab in available_labs if lab[0] == lab_id)
            )
            
            # Select device
            selected_device = st.selectbox("Seleziona Dispositivo", options=available_devices)
            
            # Quantity per student
            qty_per_student = st.number_input("Quantità per Studente", min_value=1, value=1)
            
            if st.button("Associa Dispositivo al Laboratorio"):
                # Add the requirement
                success = st.session_state.schedule_data.device_manager.add_device_requirement(
                    lab_id=selected_lab_id,
                    device_name=selected_device,
                    quantity=qty_per_student
                )
                
                if success:
                    st.success(f"Dispositivo '{selected_device}' associato al laboratorio!")
                else:
                    st.error("Errore nell'associazione del dispositivo.")
        else:
            if not available_devices:
                st.info("Aggiungi prima alcuni dispositivi.")
            else:
                st.info("Nessun laboratorio disponibile.")
        
        # Upload Excel file for device-lab associations
        st.subheader("Carica Associazioni da Excel")
        assoc_upload = st.file_uploader("Carica file Excel con associazioni", type=["xlsx", "xls"], key="assoc_upload")
        
        if assoc_upload is not None:
            try:
                # Read the Excel file
                df_assoc = pd.read_excel(assoc_upload)
                
                # Check if required columns exist
                required_cols = ["laboratorio", "dispositivo", "quantita"]
                if all(col in map(str.lower, df_assoc.columns) for col in required_cols):
                    # Get column names (case insensitive)
                    lab_col = next(col for col in df_assoc.columns if col.lower() == "laboratorio")
                    device_col = next(col for col in df_assoc.columns if col.lower() == "dispositivo")
                    qty_col = next(col for col in df_assoc.columns if col.lower() == "quantita")
                    
                    # Add each association
                    assoc_added = 0
                    for _, row in df_assoc.iterrows():
                        lab_name = row[lab_col]
                        device_name = row[device_col]
                        qty = row[qty_col]
                        
                        if pd.isna(lab_name) or pd.isna(device_name) or pd.isna(qty):
                            continue
                            
                        # Find the lab ID
                        lab_id = None
                        for lab in st.session_state.schedule_data.laboratories:
                            if lab.name.lower() == lab_name.lower():
                                lab_id = lab.id
                                break
                        
                        if lab_id is not None and device_name in st.session_state.schedule_data.device_manager.devices:
                            success = st.session_state.schedule_data.device_manager.add_device_requirement(
                                lab_id=lab_id,
                                device_name=device_name,
                                quantity=int(qty)
                            )
                            if success:
                                assoc_added += 1
                    
                    st.success(f"{assoc_added} associazioni aggiunte dal file Excel.")
                else:
                    st.error("Il file Excel deve contenere le colonne 'Laboratorio', 'Dispositivo' e 'Quantita'.")
            except Exception as e:
                st.error(f"Errore nel caricamento del file: {e}")
    
    # Display current associations
    st.subheader("Associazioni Attuali")
    lab_req_df = st.session_state.schedule_data.device_manager.get_lab_requirements_dataframe()
    
    if not lab_req_df.empty:
        # Replace lab IDs with names
        lab_names = {lab.id: lab.name for lab in st.session_state.schedule_data.laboratories}
        lab_req_df["Laboratorio"] = lab_req_df["Lab ID"].map(lab_names)
        lab_req_df = lab_req_df[["Laboratorio", "Dispositivo", "Quantità per Studente"]]
        
        st.dataframe(lab_req_df, use_container_width=True)
    else:
        st.info("Nessuna associazione dispositivo-laboratorio definita.")

# Tab 3: Inventario
with tab3:
    st.subheader("Gestione Inventario")
    st.write("In questa sezione puoi gestire l'inventario dei dispositivi.")
    
    # Create columns for different input methods
    inv_col1, inv_col2 = st.columns(2)
    
    with inv_col1:
        # Add to inventory manually
        st.subheader("Aggiorna Inventario")
        
        available_devices = list(st.session_state.schedule_data.device_manager.devices.keys())
        
        if available_devices:
            # Select device
            selected_device = st.selectbox("Seleziona Dispositivo", options=available_devices, key="inv_device_select")
            
            # Quantity to add
            qty_to_add = st.number_input("Quantità da Aggiungere", min_value=1, value=100)
            
            if st.button("Aggiorna Inventario"):
                success = st.session_state.schedule_data.device_manager.update_inventory(
                    device_name=selected_device,
                    quantity=qty_to_add
                )
                
                if success:
                    st.success(f"Aggiunti {qty_to_add} {selected_device} all'inventario!")
                else:
                    st.error("Errore nell'aggiornamento dell'inventario.")
        else:
            st.info("Aggiungi prima alcuni dispositivi nella scheda 'Dispositivi Laboratorio'.")
    
    with inv_col2:
        # Upload Excel for inventory
        st.subheader("Carica Inventario da Excel")
        inv_upload = st.file_uploader("Carica file Excel con inventario", type=["xlsx", "xls"], key="inv_upload")
        
        if inv_upload is not None:
            try:
                # Read the Excel file
                df_inv = pd.read_excel(inv_upload)
                
                # Check if required columns exist
                required_cols = ["dispositivo", "quantita"]
                if all(col in map(str.lower, df_inv.columns) for col in required_cols):
                    # Get column names (case insensitive)
                    device_col = next(col for col in df_inv.columns if col.lower() == "dispositivo")
                    qty_col = next(col for col in df_inv.columns if col.lower() == "quantita")
                    
                    # Add each inventory entry
                    inv_added = 0
                    for _, row in df_inv.iterrows():
                        device_name = row[device_col]
                        qty = row[qty_col]
                        
                        if pd.isna(device_name) or pd.isna(qty):
                            continue
                            
                        # Add to inventory if device exists
                        if device_name in st.session_state.schedule_data.device_manager.devices:
                            st.session_state.schedule_data.device_manager.update_inventory(
                                device_name=device_name,
                                quantity=int(qty)
                            )
                            inv_added += 1
                        else:
                            # Create device and add to inventory
                            st.session_state.schedule_data.device_manager.add_device(name=device_name)
                            st.session_state.schedule_data.device_manager.update_inventory(
                                device_name=device_name,
                                quantity=int(qty)
                            )
                            inv_added += 1
                    
                    st.success(f"{inv_added} voci di inventario aggiornate dal file Excel.")
                else:
                    st.error("Il file Excel deve contenere le colonne 'Dispositivo' e 'Quantita'.")
            except Exception as e:
                st.error(f"Errore nel caricamento del file: {e}")
    
    # Display current inventory
    st.subheader("Inventario Attuale")
    inv_df = st.session_state.schedule_data.device_manager.get_inventory_dataframe()
    
    if not inv_df.empty:
        # Add alert column
        inv_df["Stato"] = inv_df["Quantità"].apply(
            lambda x: "🔴 Basso" if x <= 50 else "🟢 OK"
        )
        
        st.dataframe(inv_df, use_container_width=True)
        
        # Check for low inventory alerts
        low_inv = st.session_state.schedule_data.device_manager.check_low_inventory_alerts()
        if low_inv:
            st.warning("⚠️ Alcune scorte sono basse e richiedono rifornimento!")
            for device, qty in low_inv:
                st.info(f"Dispositivo: {device} - Quantità rimanente: {qty} (sotto la soglia di 50)")
    else:
        st.info("Nessun dispositivo in inventario.")

# Tab 4: Gestione Completamento
with tab4:
    st.subheader("Gestione Completamento Laboratori")
    st.write("In questa sezione puoi segnare i laboratori completati e aggiornare automaticamente l'inventario.")
    
    if st.session_state.schedule_created:
        # Get all scheduled labs organized by date
        all_labs = st.session_state.schedule_data.scheduled_labs
        
        if all_labs:
            # Create a dictionary of labs by date
            labs_by_date = {}
            giorni = ["Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì"]
            
            for slab in all_labs:
                week = slab.time_slot.day // 5
                weekday_idx = slab.time_slot.day % 5
                weekday = giorni[weekday_idx]
                date_str = f"Settimana {week+1}, {weekday}"
                
                if date_str not in labs_by_date:
                    labs_by_date[date_str] = []
                    
                labs_by_date[date_str].append(slab)
            
            # Create selectbox for dates
            dates = sorted(labs_by_date.keys())
            selected_date = st.selectbox("Seleziona Data", options=dates)
            
            # Display labs for the selected date
            labs_on_date = labs_by_date[selected_date]
            
            st.write(f"Laboratori programmati per {selected_date}:")
            
            # Create a table with checkboxes
            for i, slab in enumerate(labs_on_date):
                lab_id = f"{slab.lab.id}_{slab.time_slot.day}_{slab.time_slot.start_time.strftime('%H%M')}"
                
                # Check if this lab is already marked as completed
                already_completed = any(
                    c.scheduled_lab.lab.id == slab.lab.id and 
                    c.scheduled_lab.time_slot.day == slab.time_slot.day and
                    c.scheduled_lab.time_slot.start_time == slab.time_slot.start_time
                    for c in st.session_state.schedule_data.device_manager.completed_labs
                )
                
                col1, col2, col3, col4 = st.columns([3, 2, 2, 1])
                with col1:
                    st.write(f"**{slab.lab.name}**")
                with col2:
                    st.write(f"{slab.time_slot.start_time.strftime('%H:%M')} - {slab.time_slot.end_time.strftime('%H:%M')}")
                with col3:
                    st.write(f"Aula: {slab.room.name}")
                with col4:
                    if already_completed:
                        st.write("✅ Completato")
                    else:
                        if st.button("Completa", key=f"complete_{lab_id}"):
                            # Check for required devices
                            success, messages = st.session_state.schedule_data.device_manager.mark_lab_completed(slab)
                            
                            if success:
                                st.success(f"Laboratorio '{slab.lab.name}' segnato come completato e inventario aggiornato!")
                                st.rerun()
                            else:
                                for msg in messages:
                                    st.error(msg)
                
                # Add a divider between labs                    
                st.markdown("---")
            
            # Display lab completion history
            completed_labs = st.session_state.schedule_data.device_manager.completed_labs
            if completed_labs:
                st.subheader("Storico Laboratori Completati")
                
                completed_data = []
                for comp in completed_labs:
                    slab = comp.scheduled_lab
                    week = slab.time_slot.day // 5
                    weekday_idx = slab.time_slot.day % 5
                    weekday = giorni[weekday_idx]
                    date_str = f"Settimana {week+1}, {weekday}"
                    
                    completed_data.append({
                        "Laboratorio": slab.lab.name,
                        "Data": date_str,
                        "Orario": f"{slab.time_slot.start_time.strftime('%H:%M')} - {slab.time_slot.end_time.strftime('%H:%M')}",
                        "Aula": slab.room.name,
                        "Data Completamento": comp.completed_date.strftime("%Y-%m-%d %H:%M")
                    })
                
                # Create and display dataframe
                completed_df = pd.DataFrame(completed_data)
                st.dataframe(completed_df, use_container_width=True)
            else:
                st.info("Nessun laboratorio è stato ancora segnato come completato.")
        else:
            st.info("Nessun laboratorio programmato da completare.")
    else:
        st.info("Genera prima una programmazione nella scheda 'Programmazione'.")
        
# Footer
st.markdown("---")
st.caption("Sistema di Programmazione Laboratori | Creato con Streamlit")