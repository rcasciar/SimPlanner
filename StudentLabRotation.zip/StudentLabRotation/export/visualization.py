"""
Visualization utilities for the lab scheduling application.
"""
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import streamlit as st
from models import ScheduleData

def create_schedule_heatmap(schedule_data: ScheduleData, view_type: str = "room"):
    """
    Create a heatmap visualization of the schedule.
    
    Args:
        schedule_data: The schedule data
        view_type: The type of view (room, lab, or day)
    
    Returns:
        A Plotly figure
    """
    df = schedule_data.get_data_frame()
    
    if df.empty:
        return None
    
    # Create a more detailed timescale
    time_range = pd.date_range("08:30", "16:30", freq="30min").strftime("%H:%M")
    
    # Prepare data for heatmap
    if view_type == "room":
        return _create_room_view(df, time_range)
    elif view_type == "lab":
        return _create_lab_view(df, time_range)
    elif view_type == "day":
        return _create_day_view(df, time_range)
    else:
        raise ValueError(f"Unknown view type: {view_type}")

def _create_room_view(df: pd.DataFrame, time_range: list) -> go.Figure:
    """Create a room-based view of the schedule"""
    
    fig = go.Figure()
    
    # Get unique rooms and dates
    rooms = sorted(df["Room"].unique())
    dates = sorted(df["Date"].unique())
    
    # Create a color scale based on labs
    labs = sorted(df["Lab"].unique())
    colors = px.colors.qualitative.Plotly
    lab_colors = {lab: colors[i % len(colors)] for i, lab in enumerate(labs)}
    
    # Add shapes and annotations for each scheduled lab
    for _, row in df.iterrows():
        room = row["Room"]
        date = row["Date"]
        lab = row["Lab"]
        start = row["Start"]
        end = row["End"]
        
        room_idx = rooms.index(room)
        date_idx = dates.index(date)
        
        # Calculate y position
        y0 = room_idx - 0.4
        y1 = room_idx + 0.4
        
        # Calculate x position based on time
        # Convert time to fraction of day
        start_dt = datetime.strptime(start, "%H:%M")
        end_dt = datetime.strptime(end, "%H:%M")
        
        day_start = datetime.strptime("08:30", "%H:%M")
        day_end = datetime.strptime("16:30", "%H:%M")
        
        # Handle lunch break
        lunch_start = datetime.strptime("12:30", "%H:%M")
        lunch_end = datetime.strptime("13:30", "%H:%M")
        
        # Calculate x position
        if end_dt <= lunch_start:
            # Before lunch
            day_length = (lunch_start - day_start).total_seconds()
            x0 = date_idx + (start_dt - day_start).total_seconds() / day_length * 0.4
            x1 = date_idx + (end_dt - day_start).total_seconds() / day_length * 0.4
        elif start_dt >= lunch_end:
            # After lunch
            day_length = (day_end - lunch_end).total_seconds()
            x0 = date_idx + 0.6 + (start_dt - lunch_end).total_seconds() / day_length * 0.4
            x1 = date_idx + 0.6 + (end_dt - lunch_end).total_seconds() / day_length * 0.4
        
        # Add rectangle for this lab
        fig.add_shape(
            type="rect",
            x0=x0,
            y0=y0,
            x1=x1,
            y1=y1,
            fillcolor=lab_colors[lab],
            opacity=0.7,
            line=dict(color="black", width=1),
            row=room_idx,
            col=date_idx,
        )
        
        # Add text annotation
        fig.add_annotation(
            x=(x0 + x1) / 2,
            y=(y0 + y1) / 2,
            text=f"{lab}<br>{start}-{end}",
            showarrow=False,
            font=dict(color="black", size=10),
        )
    
    # Create the base heatmap (just for axes)
    heatmap_data = np.zeros((len(rooms), len(dates)))
    
    fig.add_trace(
        go.Heatmap(
            z=heatmap_data,
            x=dates,
            y=rooms,
            showscale=False,
            colorscale=[[0, 'rgba(0,0,0,0)'], [1, 'rgba(0,0,0,0)']],
        )
    )
    
    # Update layout
    fig.update_layout(
        title="Schedule by Room",
        height=100 + 100 * len(rooms),
        margin=dict(l=100, r=50, t=100, b=50),
        xaxis=dict(
            title="Date",
            tickangle=45,
            side="top",
        ),
        yaxis=dict(
            title="Room",
            tickangle=0,
        ),
    )
    
    # Add legend for labs
    for i, lab in enumerate(labs):
        fig.add_trace(go.Scatter(
            x=[None],
            y=[None],
            mode='markers',
            marker=dict(size=10, color=lab_colors[lab]),
            name=lab,
            showlegend=True
        ))
    
    return fig

def _create_lab_view(df: pd.DataFrame, time_range: list) -> go.Figure:
    """Create a lab-based view of the schedule"""
    
    fig = go.Figure()
    
    # Get unique labs and dates
    labs = sorted(df["Lab"].unique())
    dates = sorted(df["Date"].unique())
    
    # Create a color scale based on rooms
    rooms = sorted(df["Room"].unique())
    colors = px.colors.qualitative.Plotly
    room_colors = {room: colors[i % len(colors)] for i, room in enumerate(rooms)}
    
    # Add shapes and annotations for each scheduled lab
    for _, row in df.iterrows():
        room = row["Room"]
        date = row["Date"]
        lab = row["Lab"]
        start = row["Start"]
        end = row["End"]
        
        lab_idx = labs.index(lab)
        date_idx = dates.index(date)
        
        # Calculate y position
        y0 = lab_idx - 0.4
        y1 = lab_idx + 0.4
        
        # Calculate x position based on time
        # Convert time to fraction of day
        start_dt = datetime.strptime(start, "%H:%M")
        end_dt = datetime.strptime(end, "%H:%M")
        
        day_start = datetime.strptime("08:30", "%H:%M")
        day_end = datetime.strptime("16:30", "%H:%M")
        
        # Handle lunch break
        lunch_start = datetime.strptime("12:30", "%H:%M")
        lunch_end = datetime.strptime("13:30", "%H:%M")
        
        # Calculate x position
        if end_dt <= lunch_start:
            # Before lunch
            day_length = (lunch_start - day_start).total_seconds()
            x0 = date_idx + (start_dt - day_start).total_seconds() / day_length * 0.4
            x1 = date_idx + (end_dt - day_start).total_seconds() / day_length * 0.4
        elif start_dt >= lunch_end:
            # After lunch
            day_length = (day_end - lunch_end).total_seconds()
            x0 = date_idx + 0.6 + (start_dt - lunch_end).total_seconds() / day_length * 0.4
            x1 = date_idx + 0.6 + (end_dt - lunch_end).total_seconds() / day_length * 0.4
        
        # Add rectangle for this lab
        fig.add_shape(
            type="rect",
            x0=x0,
            y0=y0,
            x1=x1,
            y1=y1,
            fillcolor=room_colors[room],
            opacity=0.7,
            line=dict(color="black", width=1),
            row=lab_idx,
            col=date_idx,
        )
        
        # Add text annotation
        fig.add_annotation(
            x=(x0 + x1) / 2,
            y=(y0 + y1) / 2,
            text=f"{room}<br>{start}-{end}",
            showarrow=False,
            font=dict(color="black", size=10),
        )
    
    # Create the base heatmap (just for axes)
    heatmap_data = np.zeros((len(labs), len(dates)))
    
    fig.add_trace(
        go.Heatmap(
            z=heatmap_data,
            x=dates,
            y=labs,
            showscale=False,
            colorscale=[[0, 'rgba(0,0,0,0)'], [1, 'rgba(0,0,0,0)']],
        )
    )
    
    # Update layout
    fig.update_layout(
        title="Schedule by Laboratory",
        height=100 + 100 * len(labs),
        margin=dict(l=100, r=50, t=100, b=50),
        xaxis=dict(
            title="Date",
            tickangle=45,
            side="top",
        ),
        yaxis=dict(
            title="Laboratory",
            tickangle=0,
        ),
    )
    
    # Add legend for rooms
    for i, room in enumerate(rooms):
        fig.add_trace(go.Scatter(
            x=[None],
            y=[None],
            mode='markers',
            marker=dict(size=10, color=room_colors[room]),
            name=room,
            showlegend=True
        ))
    
    return fig

def _create_day_view(df: pd.DataFrame, time_range: list) -> go.Figure:
    """Create a day-based view of the schedule"""
    
    # Create a figure with subplots, one row for each date
    dates = sorted(df["Date"].unique())
    rooms = sorted(df["Room"].unique())
    
    # Create a color scale based on labs
    labs = sorted(df["Lab"].unique())
    colors = px.colors.qualitative.Plotly
    lab_colors = {lab: colors[i % len(colors)] for i, lab in enumerate(labs)}
    
    fig = go.Figure()
    
    for date_idx, date in enumerate(dates):
        date_df = df[df["Date"] == date]
        
        for _, row in date_df.iterrows():
            room = row["Room"]
            lab = row["Lab"]
            start = row["Start"]
            end = row["End"]
            
            room_idx = rooms.index(room)
            
            # Calculate y position
            y0 = room_idx - 0.4 + date_idx * len(rooms)
            y1 = room_idx + 0.4 + date_idx * len(rooms)
            
            # Calculate x position based on time (8:30 - 16:30)
            start_dt = datetime.strptime(start, "%H:%M")
            end_dt = datetime.strptime(end, "%H:%M")
            
            # Convert to hours from 8:30
            start_hour = (start_dt - datetime(1900, 1, 1, 8, 30)).total_seconds() / 3600
            end_hour = (end_dt - datetime(1900, 1, 1, 8, 30)).total_seconds() / 3600
            
            # Add rectangle for this lab
            fig.add_shape(
                type="rect",
                x0=start_hour,
                y0=y0,
                x1=end_hour,
                y1=y1,
                fillcolor=lab_colors[lab],
                opacity=0.7,
                line=dict(color="black", width=1),
            )
            
            # Add text annotation
            fig.add_annotation(
                x=(start_hour + end_hour) / 2,
                y=(y0 + y1) / 2,
                text=f"{lab}",
                showarrow=False,
                font=dict(color="black", size=10),
            )
    
    # Create the y-axis labels
    y_labels = []
    for date in dates:
        for room in rooms:
            y_labels.append(f"{date} - {room}")
    
    # Set up figure layout
    fig.update_layout(
        title="Schedule by Day and Room",
        height=100 + 100 * len(y_labels),
        margin=dict(l=150, r=50, t=100, b=50),
        xaxis=dict(
            title="Time",
            tickvals=list(range(0, 9)),  # 8:30 to 16:30
            ticktext=[f"{h+8}:{m}" for h, m in [(0, 30), (1, 30), (2, 30), (3, 30), 
                                               (4, 30), (5, 30), (6, 30), (7, 30), (8, 0)]],
        ),
        yaxis=dict(
            title="",
            tickvals=list(range(len(y_labels))),
            ticktext=y_labels,
            autorange="reversed",  # To show first day at the top
        ),
        showlegend=True,
    )
    
    # Add legend for labs
    for i, lab in enumerate(labs):
        fig.add_trace(go.Scatter(
            x=[None],
            y=[None],
            mode='markers',
            marker=dict(size=10, color=lab_colors[lab]),
            name=lab,
            showlegend=True
        ))
    
    return fig

def create_student_assignment_chart(schedule_data: ScheduleData) -> go.Figure:
    """Create a chart showing how many students are assigned to each lab"""
    
    # Count students per lab
    lab_counts = {}
    for lab in schedule_data.laboratories:
        lab_counts[lab.name] = 0
    
    for slab in schedule_data.scheduled_labs:
        lab_counts[slab.lab.name] += len(slab.students)
    
    # Create dataframe
    df = pd.DataFrame({
        "Laboratory": list(lab_counts.keys()),
        "Students Assigned": list(lab_counts.values())
    })
    
    # Sort by student count
    df = df.sort_values("Students Assigned", ascending=False)
    
    # Create bar chart
    fig = px.bar(
        df, 
        x="Laboratory", 
        y="Students Assigned",
        title="Students Assigned per Laboratory",
        color="Laboratory",
        color_discrete_sequence=px.colors.qualitative.Plotly
    )
    
    # Update layout
    fig.update_layout(
        xaxis_tickangle=-45,
        height=500,
    )
    
    return fig
