"""
Scheduling logic for the lab rotation application.
"""
from typing import List, Dict, Set, Tuple, Optional
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
from models import Laboratory, Room, TimeSlot, ScheduledLab, ScheduleData

class LabScheduler:
    """Class to handle the scheduling of labs"""
    
    def __init__(self, schedule_data: ScheduleData):
        self.data = schedule_data
        self.student_lab_assignments: Dict[int, Set[int]] = {i: set() for i in range(1, self.data.total_students + 1)}
        self.room_schedule: Dict[str, List[Tuple[int, TimeSlot]]] = {room.name: [] for room in self.data.rooms}
        
    def create_schedule(self) -> bool:
        """Create a complete schedule for all labs"""
        # Gestione speciale per gruppi molto piccoli (5 o meno studenti)
        if self.data.total_students <= 5:
            return self._create_small_group_schedule()
            
        # Altrimenti usa l'algoritmo standard
        # First schedule the regular labs
        regular_labs = [lab for lab in self.data.laboratories if not lab.is_small_capacity]
        for lab in regular_labs:
            success = self._schedule_lab(lab)
            if not success:
                return False
                
        # Then schedule the small capacity labs that must be at the end
        small_labs = [lab for lab in self.data.laboratories if lab.is_small_capacity]
        for lab in small_labs:
            success = self._schedule_lab(lab)
            if not success:
                return False
                
        return True
        
    def _create_small_group_schedule(self) -> bool:
        """Algoritmo speciale per gruppi molto piccoli (5 o meno studenti)"""
        # Quando abbiamo pochi studenti, tutti i laboratori possono essere svolti da tutti gli studenti insieme
        all_students = list(range(1, self.data.total_students + 1))
        
        # Programma tutti i lab negli stessi orari su giorni diversi
        day = 0
        
        for lab in self.data.laboratories:
            # Cerca una stanza disponibile (qualsiasi stanza va bene con pochi studenti)
            room = next(r for r in self.data.rooms if r.name in lab.allowed_rooms)
            
            # Crea un time slot fisso per ogni lab
            # Usiamo un orario fisso 9:00-12:00 o 13:30-16:30 a seconda della durata
            if lab.duration_minutes <= 180:
                start_time = datetime(2023, 1, 1, 9, 0)
                end_time = datetime(2023, 1, 1, 12, 0)
            else:
                start_time = datetime(2023, 1, 1, 13, 30)
                end_time = datetime(2023, 1, 1, 16, 30)
                
            time_slot = TimeSlot(day=day, start_time=start_time, end_time=end_time)
            
            # Crea il lab programmato
            scheduled_lab = ScheduledLab(
                lab=lab,
                room=room,
                time_slot=time_slot,
                students=all_students.copy()
            )
            
            # Aggiorna i dati di scheduling
            self.data.scheduled_labs.append(scheduled_lab)
            for student in all_students:
                self.student_lab_assignments[student].add(lab.id)
            self.room_schedule[room.name].append((lab.id, time_slot))
            
            # Passa al giorno successivo
            day += 1
            if day >= 14:  # Se supera i 14 giorni, termina
                break
                
        return True
    
    def _generate_time_slots(self, day: int) -> List[TimeSlot]:
        """Generate possible time slots for a given day"""
        time_slots = []
        
        # Start time is 8:30 AM
        start_time = datetime(2023, 1, 1, 8, 30)
        
        # End time is 16:30 (4:30 PM)
        end_time = datetime(2023, 1, 1, 16, 30)
        
        # Lunch break (1 hour) at 12:30 to 13:30
        lunch_start = datetime(2023, 1, 1, 12, 30)
        lunch_end = datetime(2023, 1, 1, 13, 30)
        
        # Generate slots with 30-minute increments
        current = start_time
        while current < end_time:
            # Skip generating slots that would overlap with lunch
            if current < lunch_start and current.hour == 12 and current.minute == 0:
                # If we're at 12:00, next slot would overlap with lunch, so jump to after lunch
                current = lunch_end
                continue
                
            # Genera slot tempo utilizzando tutte le durate necessarie per i laboratori
            # Ottieni tutte le durate uniche dai laboratori
            lab_durations = set(lab.duration_minutes for lab in self.data.laboratories)
            
            # Generate time slots for each lab duration
            for duration in lab_durations:
                end = current + timedelta(minutes=duration)
                
                # Check if the slot extends beyond the end of the day
                if end > end_time:
                    continue
                    
                # Check if the slot overlaps with lunch break
                if not (end <= lunch_start or current >= lunch_end):
                    continue
                    
                time_slots.append(TimeSlot(day=day, start_time=current, end_time=end))
            
            # Move to next 30-minute increment
            current += timedelta(minutes=30)
            
        return time_slots
    
    def _get_available_rooms(self, lab: Laboratory, time_slot: TimeSlot) -> List[Room]:
        """Get available rooms for a specific lab at a given time slot"""
        available_rooms = []
        
        for room in self.data.rooms:
            # Check if the lab is allowed in this room
            if room.name not in lab.allowed_rooms:
                continue
                
            # Check if the room is already booked during this time slot
            is_available = True
            for booked_lab_id, booked_slot in self.room_schedule[room.name]:
                if time_slot.overlaps(booked_slot):
                    is_available = False
                    break
                    
            if is_available:
                available_rooms.append(room)
                
        return available_rooms
    
    def _get_available_students(self, lab: Laboratory, time_slot: TimeSlot) -> List[int]:
        """Get students available during the given time slot"""
        # Get all students
        all_students = list(range(1, self.data.total_students + 1))
        
        # Filter out students who already have the lab
        available_students = [s for s in all_students if lab.id not in self.student_lab_assignments[s]]
        
        # Filter out students who have a conflicting schedule
        for scheduled_lab in self.data.scheduled_labs:
            if time_slot.overlaps(scheduled_lab.time_slot):
                # Remove students participating in the conflicting lab
                available_students = [s for s in available_students if s not in scheduled_lab.students]
                
        return available_students
    
    def _schedule_lab(self, lab: Laboratory) -> bool:
        """Schedule a single lab, potentially across multiple sessions"""
        students_to_schedule = [s for s in range(1, self.data.total_students + 1) 
                               if lab.id not in self.student_lab_assignments[s]]
        
        # Adattamento per gruppi piccoli di studenti
        if self.data.total_students <= 10:
            # Riduzione del requisito minimo di studenti per gruppi piccoli
            adjusted_min_students = min(lab.min_students, max(1, self.data.total_students // 2))
        else:
            adjusted_min_students = lab.min_students
        
        # Keep scheduling sessions until all students have been assigned
        while students_to_schedule:
            success = False
            
            # Try each day
            for day in range(14):  # 14 days
                # Generate possible time slots for this day
                time_slots = self._generate_time_slots(day)
                
                # Try each time slot
                for time_slot in time_slots:
                    # Skip if time slot duration doesn't match lab duration
                    if time_slot.duration_minutes() != lab.duration_minutes:
                        continue
                        
                    # Get available rooms
                    available_rooms = self._get_available_rooms(lab, time_slot)
                    
                    # Try each room
                    for room in available_rooms:
                        # Get available students
                        available_students = [s for s in students_to_schedule if s in 
                                            self._get_available_students(lab, time_slot)]
                        
                        # Per gruppi piccoli, usiamo il minimo adattato
                        if len(available_students) < adjusted_min_students:
                            continue
                            
                        # Determine how many students to assign (up to max capacity)
                        students_to_assign = available_students[:min(len(available_students), lab.max_students)]
                        
                        # Create the scheduled lab
                        scheduled_lab = ScheduledLab(
                            lab=lab,
                            room=room,
                            time_slot=time_slot,
                            students=students_to_assign
                        )
                        
                        # Update scheduling data
                        self.data.scheduled_labs.append(scheduled_lab)
                        for student in students_to_assign:
                            self.student_lab_assignments[student].add(lab.id)
                        self.room_schedule[room.name].append((lab.id, time_slot))
                        
                        # Remove assigned students from the pool
                        students_to_schedule = [s for s in students_to_schedule if s not in students_to_assign]
                        
                        success = True
                        break
                    
                    if success or not students_to_schedule:
                        break
                
                if success or not students_to_schedule:
                    break
            
            # Se abbiamo pochissimi studenti totali e abbiamo già programmato almeno un laboratorio
            # possiamo considerarlo un successo anche se non abbiamo programmato tutti gli studenti
            if not success and students_to_schedule:
                if self.data.total_students <= 5 and any(lab.id in labs for labs in self.student_lab_assignments.values()):
                    return True
                return False
        
        return True
    
    def optimize_schedule(self) -> bool:
        """Attempt to optimize the schedule by balancing student workload"""
        # This is a simple implementation that tries to balance lab assignments
        # A more sophisticated algorithm could be implemented if needed
        
        # Count labs per student
        lab_counts = {student_id: len(labs) for student_id, labs in self.student_lab_assignments.items()}
        
        # Check if everyone has all labs
        if all(count == len(self.data.laboratories) for count in lab_counts.values()):
            return True
            
        return False
